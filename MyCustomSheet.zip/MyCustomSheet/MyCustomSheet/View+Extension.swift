//
//  View+Extension.swift
//  MyCustomSheet
//
//  Created by Vishal Kundaliya on 02/10/24.
//

import SwiftUI

public extension View {
    var screenSize: CGSize {
        UIScreen.main.bounds.size
    }
    
    var isSmallDevice: Bool {
        screenSize.height <= 667
    }
    
    var widthRatio: CGFloat {
        screenSize.width / 414
    }
}

