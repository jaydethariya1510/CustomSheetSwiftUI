//
//  ContentView.swift
//  MyCustomSheet
//
//  Created by Vishal Kundaliya on 02/10/24.
//

import SwiftUI
import DMSansFonts

enum SheetDestination: Identifiable, Equatable {
    case sheet1
    case sheet2
    case sheet3
    case sheet4

    var id: Self {
        self
    }
}

struct ContentView: View {
    @State var isShowAppSheet: Bool = false
    @State var sheetDest: SheetDestination?
    
    var body: some View {
        VStack {
            Button("Show Sheet Single") {
                isShowAppSheet = true
            }
            
            Button("Sheet1") {
                sheetDest = .sheet1
            }
            Button("Sheet2") {
                sheetDest = .sheet2
            }
            Button("Sheet3") {
                sheetDest = .sheet3
            }
            Button("Sheet4") {
                sheetDest = .sheet4
            }
        }
        .appSheet(isShowSheet: $isShowAppSheet, isShowArrow: true) {
            AppSheetContainerView(title: "Hello") {
                ContactSupportView {
                    isShowAppSheet = false
                }
            }
        }
        .appSheet(selectedSheet: $sheetDest, isShowArrow: true) { sheet in
            switch sheet {
            case .sheet1:
                Color.red.frame(height: 400)
            case .sheet2:
                Color.blue.frame(height: 400)
            case .sheet3:
                Color.green.frame(height: 400)
            case .sheet4:
                Color.yellow.frame(height: 400)
            }
        }
    }
}


struct ContactSupportView: View {
    let closeAction: () -> Void
    
    var body: some View {
        VStack(spacing: 24) {
            VStack(spacing: 20) {
                Group {
                    Label(title: {
                        Text("Telegram")
                    }) {
                        Image(.tg)
                    }
                    .onTapGesture {
                        print("Telegram.......")
                    }
                    
                    Label(title: {
                        Text("WhatsApp")
                    }) {
                        Image(.whatsApp)
                    }
                    .onTapGesture {
                        print("WhatsApp.......")
                    }
                }
                .dmSansRegular(.md)
                .foregroundStyle(.bulma)
                .padding(4)
            }
            
            Label("Cancel", systemImage: "xmark")
                .dmSansRegular(.md)
                .foregroundStyle(.bulma)
                .padding(.bottom)
                .onTapGesture {
                }
        }
        .frame(maxWidth: .infinity)
    }
}

struct AppSheetContainerView<Content: View>: View {
    let title: String
    @ViewBuilder var content: () -> Content

    var body: some View {
        VStack(spacing: 0) {
            Capsule()
                .fill(Color.beerus)
                .frame(width: 40, height: 4)
                .padding(.top, 8)
            Spacer()
                .frame(height: 8)
            TitleLabel(title: title, size: .lg)
                .padding(.bottom, isSmallDevice ? 10 : 24)
            VStack(spacing: 12) {
                content()
            }
            .padding(.vertical, 8)
            .contentShape(Rectangle())
            .padding(.bottom, isSmallDevice ? 16 : 32)
            .padding(.horizontal, isSmallDevice ? 6 : 12)
        }
        .background { Color.gohan }
    }
}

struct TitleLabel: View {
    let title: String
    let size: FontSize

    init(title: String, size: FontSize = .xl3) {
        self.title = title
        self.size = size
    }

    var body: some View {
        Text(title)
            .dmSansRegular(size)
            .foregroundStyle(.bulma)
    }
}
