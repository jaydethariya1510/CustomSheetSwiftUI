//
//  MyCustomSheetApp.swift
//  MyCustomSheet
//
//  Created by Vishal Kundaliya on 02/10/24.
//

import SwiftUI

@main
struct MyCustomSheetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
