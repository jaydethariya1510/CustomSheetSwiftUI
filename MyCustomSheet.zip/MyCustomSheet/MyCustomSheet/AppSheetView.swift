//
//  AppSheetView.swift
//  MyCustomSheet
//
//  Created by Vishal Kundaliya on 29/11/24.
//

import Foundation
import SwiftUI

extension View {
    func appSheet<SheetContent: View>(
        isShowSheet: Binding<Bool>,
        isShowArrow: Bool = false,
        @ViewBuilder sheetContent: @escaping () -> SheetContent
    ) -> some View {
        self.modifier(
            AppSheetModifier(
                isShowSheet: isShowSheet,
                isShowArrow: isShowArrow,
                sheetContent: sheetContent
            )
        )
    }
}

private struct AppSheetModifier<SheetContent: View>: ViewModifier {
    @Binding var isShowSheet: Bool
    let isShowArrow: Bool
    @ViewBuilder var sheetContent: () -> SheetContent
    
    func body(content: Content) -> some View {
        ZStack {
            content
            
            if isShowSheet {
                Color.backdrop
                    .ignoresSafeArea()
                    .onTapGesture {
                        isShowSheet = false
                    }
                    .transition(.opacity)
            }
            
            VStack(spacing: 0) {
                Spacer()
                if isShowSheet {
                    GenericSheetContent(
                        isShowSheet: $isShowSheet,
                        isShowArrow: isShowArrow,
                        sheetContent: { sheetContent() }
                    )
                    .transition(.move(edge: .bottom))
                }
            }
            .ignoresSafeArea()
        }
        .animation(.easeInOut(duration: 0.5), value: isShowSheet)
    }
}

private struct GenericSheetContent<SheetContent: View>: View {
    @Binding var isShowSheet: Bool
    let isShowArrow: Bool
    @ViewBuilder var sheetContent: SheetContent
    @State private var translation: CGFloat = 0
    
    var body: some View {
        VStack(spacing: 0) {
            if isShowArrow {
                Image(.chevronDownSheetV31Img)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 36, height: 8)
                    .rotationEffect(.degrees(180))
                    .padding(.bottom, 10)
            }
            self.sheetContent
                .background {
                    Color.goku
                        .ignoresSafeArea()
                }
                .clipShape(.rect(cornerRadii: .init(topLeading: 20, topTrailing: 20)))
        }
        .offset(y: translation)
        .simultaneousGesture(dragGesture)
    }
    
    var dragGesture: some Gesture {
        DragGesture(minimumDistance: 0)
            .onChanged { value in
                guard value.translation.height > 0 else {
                    return
                }
                self.translation = value.translation.height
            }
            .onEnded { value in
                if value.translation.height > 20 {
                    self.isShowSheet = false
                } else {
                    withAnimation(.easeInOut(duration: 0.5)) {
                        translation = 0
                    }
                }
            }
    }
}

///======================== For Item ========================
extension View {
    func appSheet<Sheet: Identifiable & Equatable, SheetContent: View>(
        selectedSheet: Binding<Sheet?>,
        isShowArrow: Bool = false,
        @ViewBuilder content: @escaping (Sheet) -> SheetContent
    ) -> some View {
        self.modifier(
            AppSheetForItemModifier(
                selectedSheet: selectedSheet,
                isShowArrow: isShowArrow,
                sheetContent: content
            )
        )
    }
}

private struct AppSheetForItemModifier<Sheet: Identifiable & Equatable, SheetContent: View>: ViewModifier {
    @Binding var selectedSheet: Sheet?
    let isShowArrow: Bool
    @ViewBuilder var sheetContent: (Sheet) -> SheetContent
    
    func body(content: Content) -> some View {
        ZStack {
            content
            
            if selectedSheet != nil {
                Color.black.opacity(0.5)
                    .ignoresSafeArea()
                    .onTapGesture {
                        selectedSheet = nil
                    }
                    .transition(.opacity)
            }
            
            VStack(spacing: 0) {
                Spacer()
                if let sheet = selectedSheet {
                    GenericSheetContentForItem(
                        selectedSheet: $selectedSheet,
                        isShowArrow: isShowArrow,
                        sheetContent: { sheetContent(sheet) }
                    )
                    .transition(.move(edge: .bottom))
                }
            }
            .ignoresSafeArea(.all, edges: .bottom)
        }
        .animation(.easeInOut(duration: 0.5), value: selectedSheet)
    }
}

private struct GenericSheetContentForItem<Sheet: Identifiable & Equatable, Content: View>: View {
    @Binding var selectedSheet: Sheet?
    let isShowArrow: Bool
    @ViewBuilder var sheetContent: Content
    @State private var translation: CGFloat = 0
    
    var body: some View {
        VStack(spacing: 0) {
            if isShowArrow {
                Image(.chevronDownSheetV31Img)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 36, height: 8)
                    .rotationEffect(.degrees(180))
                    .padding(.bottom, 10)
            }
            sheetContent
                .background {
                    Color.goku
                        .ignoresSafeArea()
                }
                .clipShape(.rect(cornerRadii: .init(topLeading: 20, topTrailing: 20)))
                .onDisappear {
                    translation = .zero
                }
        }
        .offset(y: translation)
        .simultaneousGesture(dragGesture)
    }
    
    var dragGesture: some Gesture {
        DragGesture(minimumDistance: 0)
            .onChanged { value in
                guard value.translation.height > 0 else {
                    return
                }
                self.translation = value.translation.height
            }
            .onEnded { value in
                if value.translation.height > 20 {
                    self.selectedSheet = nil
                } else {
                    withAnimation {
                        translation = 0
                    }
                }
            }
    }
}
