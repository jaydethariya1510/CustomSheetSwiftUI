//
//  FontExtension.swift
//  MyCustomSheet
//
//  Created by Vishal Kundaliya on 28/11/24.
//

import Foundation
import SwiftUI

public enum FontSize: CGFloat {
  /// font size 8
  case xs3 = 8
  /// font size 10
  case xs2 = 10
  /// font size 12
  case xs = 12
  /// font size 14
  case sm = 14
  /// font size 16
  case md = 16
  /// font size 18
  case lg = 18
  /// font size 20
  case xl = 20
  /// font size 24
  case xl2 = 24
  /// font size 32
  case xl3 = 32
  /// font size 40
  case xl4 = 40
  /// font size 48
  case xl5 = 48
  /// font size 56
  case xl6 = 56
  /// font size 64
  case xl7 = 64
}

public extension View {
    func dmSansRegular(_ fontSize: FontSize) -> some View {
      dmSansRegular(fontSize.rawValue)
    }

    func dmSansMedium(_ fontSize: FontSize) -> some View {
      dmSansMedium(fontSize.rawValue)
    }
}

public extension Text {
  func dmSansRegular(_ fontSize: FontSize) -> Text {
    dmSansFont(.regular, size: fontSize.rawValue)
  }

  func dmSansMedium(_ fontSize: FontSize) -> Text {
    dmSansFont(.medium, size: fontSize.rawValue)
  }
}
